# Zona PPR · NFL 2026

Página HTML con catálogo de jugadores, proyecciones PPR de 18 semanas, noticias y simulador de siete titulares. No requiere instalar paquetes ni compilar.

## Subir a GitHub

1. Descomprime el ZIP.
2. Crea un repositorio en GitHub.
3. Selecciona **Add file → Upload files** y sube el contenido de esta carpeta. No subas el ZIP.
4. Comprueba que `index.html` y `vercel.json` estén en la raíz del repositorio; confirma con **Commit changes**.

## Publicar en Vercel

1. En Vercel, selecciona **Add New → Project** e importa el repositorio de GitHub.
2. Usa **Framework Preset: Other** y **Root Directory: ./ ** (la raíz).
3. No establezcas comandos de instalación ni compilación. La carpeta de salida es `.`. El archivo `vercel.json` ya incluye estos valores.
4. Pulsa **Deploy** y abre el enlace que genere Vercel.

Documentación: https://vercel.com/docs/builds/configure-a-build

## Datos y actualizaciones

- Incluye una copia de los datos de las 18 semanas de 2026. Consulta la fecha visible en la página.
- Al abrir y cada cinco minutos mientras la página está visible, intenta consultar proyecciones de Sleeper y noticias de ESPN.
- Requiere conexión y que las fuentes permitan consultas desde el navegador. Si fallan, conserva la copia y muestra el estado.
- El calendario, catálogo y récords NFL de esta versión HTML son una copia guardada; no se actualizan con el botón. Las proyecciones y noticias sí se consultan. Una actualización de esos datos requiere reemplazar el archivo.
- Las noticias se muestran en su idioma original. Las proyecciones no garantizan resultados.
- La alineación se guarda en el navegador del usuario; no se sincroniza entre dispositivos. El equipo guardado en el HTML local no se transfiere automáticamente al dominio de Vercel.
- No contiene claves privadas, cuentas ni contraseñas. No requiere variables de entorno.

## Archivos

- `index.html`: página completa, estilos, interacciones y datos guardados.
- `vercel.json`: configuración de despliegue estático.
- `.gitignore`: exclusiones para Git.

Este paquete está preparado para importarlo. No se ha creado un repositorio ni publicado un despliegue en tu cuenta.
